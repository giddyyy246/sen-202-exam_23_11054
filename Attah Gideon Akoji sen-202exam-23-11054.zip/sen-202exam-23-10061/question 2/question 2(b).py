from django.contrib import admin
from .models import Manager, Intern, Address

admin.site.register(Manager)
admin.site.register(Intern)
admin.site.register(Address)
# Superuser login credentials for testing:
# Username: Dannyxr9
# Email: adodaniel580@gmail.com
# Password: Password123!@