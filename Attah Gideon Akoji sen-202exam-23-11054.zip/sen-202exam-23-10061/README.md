# sen-202exam-23-10061
ado daniel bialose
vug/sen/23/10061
question 1(a)
